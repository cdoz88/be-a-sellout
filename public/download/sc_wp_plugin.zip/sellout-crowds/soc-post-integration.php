<?php
/**
 * Plugin Name: Sellout Crowds Integration
 * Description: A plugin to create or update posts on Sellout Crowds site upon post creation or editing.
 * Version: 1.0
 * Author: Sellout Crowds
 * Author URI: https://selloutcrowds.com
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin constants
define( 'SOC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SOC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Add settings link on plugins page
function soc_add_settings_link( $links ) {
    $settings_link = '<a href="' . admin_url( 'options-general.php?page=soc-dashboard' ) . '">Settings</a>';
    array_unshift( $links, $settings_link );
    return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'soc_add_settings_link' );

// Include necessary files
require_once SOC_PLUGIN_DIR . 'includes/class-soc-settings.php';
require_once SOC_PLUGIN_DIR . 'includes/class-soc-api.php';
require_once SOC_PLUGIN_DIR . 'includes/class-soc-integration.php';
require_once SOC_PLUGIN_DIR . 'includes/class-soc-post-meta.php';
require_once SOC_PLUGIN_DIR . 'includes/functions.php';

function soc_initialize_plugin() {
    new SOC_Settings();
    new SOC_API();
    new SOC_Integration();
    new SOC_Post_Meta();
}
add_action( 'plugins_loaded', 'soc_initialize_plugin' );