<?php
class SOC_Settings {

    // OAuth Configuration
    private $client_id = 'wordpress_global_app';
    private $hub_auth_url = 'https://office.selloutcrowds.com/oauth/authorize';
    private $hub_token_url = 'https://office.selloutcrowds.com/oauth/token';

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'create_admin_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_init', array( $this, 'handle_oauth_callback' ) );
        add_action( 'admin_init', array( $this, 'handle_synced_posts_update' ) ); // Registers our new update handler
        
        add_action( 'show_user_profile', array( $this, 'add_soc_user_profile_url_field' ) );
        add_action( 'edit_user_profile', array( $this, 'add_soc_user_profile_url_field' ) );
        add_action( 'personal_options_update', array( $this, 'save_soc_user_profile_url_field' ) );
        add_action( 'edit_user_profile_update', array( $this, 'save_soc_user_profile_url_field' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'load_custom_admin_style' ) );
    }

    public function load_custom_admin_style() {
        echo '<style>
            #toplevel_page_soc-dashboard .wp-menu-image img {
                width: 20px;
                height: auto;
                padding-top: 7px;
            }
            .soc-table-form { margin: 0; display: flex; gap: 10px; align-items: center; }
        </style>';
    }

    public function create_admin_menu() {
        add_menu_page( 'Sellout Crowds', 'Sellout Crowds', 'manage_options', 'soc-dashboard', array($this, 'render_dashboard_page'), SOC_PLUGIN_URL . 'includes/images/icon.png', 30 );
        // We removed the separate Instructions sub-menu page to keep everything streamlined on the main dashboard
        add_submenu_page('soc-dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'soc-dashboard', array($this, 'render_dashboard_page'));
        
        // Add the new Synced Posts page
        add_submenu_page('soc-dashboard', 'Synced Posts', 'Synced Posts', 'manage_options', 'soc-synced-posts', array($this, 'render_synced_posts_page'));
    }

    /**
     * Handles the form submission from the Synced Posts page to update the community.
     */
    public function handle_synced_posts_update() {
        if ( isset($_POST['soc_update_community']) && check_admin_referer('soc_update_community_nonce') ) {
            
            $post_id = intval($_POST['post_id']);
            $new_community = sanitize_text_field($_POST['soc_allow_view']);

            // Update the local WordPress post meta
            if (empty($new_community)) {
                delete_post_meta($post_id, '_soc_allow_view');
            } else {
                update_post_meta($post_id, '_soc_allow_view', $new_community);
            }

            // Trigger the API call to update Sellout Crowds
            $post = get_post($post_id);
            if ($post && $post->post_status === 'publish') {
                $soc_api = new SOC_API();
                $post_image_link = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
                $author_una_url = get_user_meta($post->post_author, 'soc_user_profile_url', true);
                
                // Fire the edit API request
                $soc_api->editPost($post_id, $post->post_title, $post->post_content, $post_image_link, get_permalink($post), $author_una_url);
            }

            // Redirect back to the page with a success message
            wp_redirect(admin_url('admin.php?page=soc-synced-posts&soc_updated=true'));
            exit;
        }
    }

    /**
     * Renders the Synced Posts management dashboard.
     */
    public function render_synced_posts_page() {
        // Fetch API data to populate the community dropdowns
        $api_data = get_soc_api_allow_to_fields();
        $options = (isset($api_data['allow_view_to']['values']) && is_array($api_data['allow_view_to']['values'])) ? $api_data['allow_view_to']['values'] : [];
        
        // Use the bulletproof owned communities fetcher if it exists in your functions.php
        $owned_ids = function_exists('get_soc_owned_profile_ids') ? get_soc_owned_profile_ids() : [];

        // Query all posts that have been sent to Sellout Crowds
        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'meta_key'       => '_soc_post_id'
        );
        $query = new WP_Query($args);
        ?>
        
        <div class="wrap">
            <h1>Sellout Crowds - Synced Posts</h1>
            <p>View and manage all WordPress articles that have been synced to your Sellout Crowds communities.</p>

            <?php if (isset($_GET['soc_updated']) && $_GET['soc_updated'] == 'true'): ?>
                <div class="notice notice-success is-dismissible"><p>Post community updated and synced to Sellout Crowds successfully!</p></div>
            <?php endif; ?>

            <table class="wp-list-table widefat fixed striped" style="margin-top: 20px;">
                <thead>
                    <tr>
                        <th style="width: 35%;">Post Title</th>
                        <th style="width: 15%;">WordPress Status</th>
                        <th style="width: 50%;">Sellout Crowds Community</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query->have_posts()): while ($query->have_posts()): $query->the_post(); 
                        $post_id = get_the_ID();
                        $current_community = get_post_meta($post_id, '_soc_allow_view', true);
                    ?>
                    <tr>
                        <td>
                            <strong><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>"><?php the_title(); ?></a></strong>
                            <div class="row-actions">
                                <span class="edit"><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>">Edit Post</a></span>
                            </div>
                        </td>
                        <td><?php echo ucfirst(get_post_status()); ?></td>
                        <td>
                            <form method="post" action="" class="soc-table-form">
                                <?php wp_nonce_field('soc_update_community_nonce'); ?>
                                <input type="hidden" name="soc_update_community" value="1">
                                <input type="hidden" name="post_id" value="<?php echo esc_attr($post_id); ?>">
                                
                                <select name="soc_allow_view" style="max-width: 250px;">
                                    <option value="">No Community (Hidden)</option>
                                    <?php 
                                    if (!empty($options)) {
                                        $hidden_options = array('Public', 'Friends', 'Only me');
                                        foreach ($options as $label) {
                                            if (isset($label['key']) && isset($label['value'])) {
                                                // Hide base UNA default privacies
                                                if (in_array(trim($label['value']), $hidden_options)) {
                                                    continue;
                                                }
                                                
                                                // Filter by ownership if the ownership function is active
                                                if (!empty($owned_ids) && !isset($owned_ids['is_error'])) {
                                                    $community_profile_id = abs(intval($label['key']));
                                                    if (!in_array($community_profile_id, $owned_ids, true)) {
                                                        continue;
                                                    }
                                                }

                                                echo '<option value="' . esc_attr($label['key']) . '" ' . selected($current_community, $label['key'], false) . '>' . esc_html($label['value']) . '</option>';
                                            }
                                        }
                                    }
                                    ?>
                                </select>
                                <?php submit_button('Update & Sync', 'secondary', 'submit', false); ?>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                    <tr>
                        <td colspan="3">No posts have been synced to Sellout Crowds yet.</td>
                    </tr>
                    <?php endif; wp_reset_postdata(); ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function handle_oauth_callback() {
        if ( isset($_POST['soc_disconnect']) && check_admin_referer('soc_disconnect_nonce') ) {
            delete_option('soc_access_token');
            delete_option('soc_profile_url'); 
            delete_transient('soc_communities_cache'); 
            
            // Clear ownership cache if it exists
            if(function_exists('get_soc_owned_profile_ids')) {
                delete_transient('soc_owned_communities_cache');
            }

            wp_redirect(admin_url('admin.php?page=soc-dashboard'));
            exit;
        }

        // Added functionality for a manual cache refresh if you implemented it in your dashboard
        if ( isset($_POST['soc_refresh_cache']) && check_admin_referer('soc_refresh_cache_nonce') ) {
            delete_transient('soc_communities_cache');
            if(function_exists('get_soc_owned_profile_ids')) {
                delete_transient('soc_owned_communities_cache');
            }
            wp_redirect(admin_url('admin.php?page=soc-dashboard&soc_refreshed=true'));
            exit;
        }

        if ( isset($_GET['page']) && $_GET['page'] === 'soc-dashboard' && isset($_GET['code']) ) {
            $code = sanitize_text_field($_GET['code']);
            $redirect_uri = admin_url('admin.php?page=soc-dashboard');

            $response = wp_remote_post($this->hub_token_url, array(
                'body' => array(
                    'grant_type'   => 'authorization_code',
                    'client_id'    => $this->client_id,
                    'redirect_uri' => $redirect_uri,
                    'code'         => $code
                ),
                'timeout' => 15
            ));

            if ( !is_wp_error($response) ) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);

                if ( isset($data['access_token']) ) {
                    update_option('soc_access_token', sanitize_text_field($data['access_token']));
                    
                    if ( isset($data['profile_url']) && !empty($data['profile_url']) ) {
                        $raw_url = esc_url_raw($data['profile_url']);
                        $clean_url = str_replace(array('https://studio.selloutcrowds.com', 'https://www.selloutcrowds.com'), 'https://selloutcrowds.com', $raw_url);
                        update_option('soc_profile_url', $clean_url);
                    }

                    wp_redirect(admin_url('admin.php?page=soc-dashboard&soc_connected=true'));
                    exit;
                }
            }
        }
    }

    public function render_dashboard_page() {
        $access_token = get_option('soc_access_token');
        $is_connected = !empty($access_token);
        
        $redirect_uri = urlencode(admin_url('admin.php?page=soc-dashboard'));
        $connect_url = $this->hub_auth_url . '?response_type=code&client_id=' . $this->client_id . '&redirect_uri=' . $redirect_uri;
        ?>
        <div class="wrap">
            <h1>Post your articles to Sellout Crowds</h1>
            <p style="font-size: 14px; max-width: 800px;">Connect your WordPress site to Sellout Crowds to post articles directly to the Crowds and Spaces your brand manages.</p>
            
            <?php if (isset($_GET['soc_connected']) && $_GET['soc_connected'] == 'true'): ?>
                <div class="notice notice-success is-dismissible"><p>Successfully connected to Sellout Crowds!</p></div>
            <?php endif; ?>

            <?php if (isset($_GET['soc_refreshed']) && $_GET['soc_refreshed'] == 'true'): ?>
                <div class="notice notice-success is-dismissible"><p>Your communities list has been refreshed successfully!</p></div>
            <?php endif; ?>

            <?php if (isset($_GET['soc_error']) && $_GET['soc_error'] == 'access_denied'): ?>
                <div class="notice notice-error is-dismissible"><p>Connection was canceled.</p></div>
            <?php endif; ?>

            <div style="margin-top: 30px;">
                <h2>1. Connect your account</h2>
                
                <?php if ($is_connected): ?>
                    <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; max-width: 600px; margin-top: 10px; margin-bottom: 30px;">
                        <h3 style="margin-top: 0; color: #46b450; font-size: 18px;">Connected</h3>
                        <p>Your WordPress site is successfully connected to your Sellout Crowds account.</p>
                        
                        <div style="background: #f8f9f9; padding: 15px; border-radius: 4px; margin-bottom: 20px; border-left: 4px solid #46b450;">
                            <strong>Master Sellout Crowds Profile:</strong><br>
                            <span style="font-size:12px; color:#666;">This profile was securely linked via OAuth and determines the communities available.</span><br>
                            
                            <?php $master_url = get_option('soc_profile_url'); ?>
                            <?php if (empty($master_url)): ?>
                                <input type="text" value="Error: Profile URL failed to sync. Please disconnect and try again." class="regular-text" style="width: 100%; margin-top: 8px; margin-bottom: 8px; background-color: #fcebeb; color: #d63638; font-weight: bold;" readonly disabled>
                            <?php else: ?>
                                <input type="url" value="<?php echo esc_attr($master_url); ?>" class="regular-text" style="width: 100%; margin-top: 8px; margin-bottom: 8px; background-color: #e2e4e7; color: #555; cursor: not-allowed;" readonly disabled>
                            <?php endif; ?>
                        </div>

                        <div style="border-top: 1px solid #eee; padding-top: 15px;">
                            <form method="post" action="" style="display: inline-block; margin-right: 10px;">
                                <?php wp_nonce_field('soc_refresh_cache_nonce'); ?>
                                <input type="hidden" name="soc_refresh_cache" value="1">
                                <?php submit_button('Refresh Communities', 'secondary', 'submit', false); ?>
                            </form>

                            <form method="post" action="" style="display: inline-block;">
                                <?php wp_nonce_field('soc_disconnect_nonce'); ?>
                                <input type="hidden" name="soc_disconnect" value="1">
                                <?php submit_button('Disconnect', 'delete', 'submit', false); ?>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; max-width: 600px; margin-top: 10px; margin-bottom: 30px;">
                        <h3 style="margin-top: 0; font-size: 18px;">Not Connected</h3>
                        <p style="margin-bottom: 20px;">Connect your WordPress site to Sellout Crowds to start syncing your posts to your communities.</p>
                        <a href="<?php echo esc_url($connect_url); ?>" class="button button-primary button-hero">Connect to Sellout Crowds</a>
                    </div>
                <?php endif; ?>

                <h2>2. For each writer on your WordPress site</h2>
                <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; max-width: 600px; margin-top: 10px; margin-bottom: 30px;">
                    <ol style="margin-top: 0; margin-bottom: 0; padding-left: 20px;">
                        <li style="margin-bottom: 10px;">Each WordPress user needs to locate the 'Sellout Crowds Profile Settings' box in their WordPress user profile and enter their Sellout Crowds profile URL.<br>Example: <code>https://www.selloutcrowds.com/profile/username</code></li>
                        <li>This is used to credit the WordPress user as the author on Sellout Crowds.</li>
                    </ol>
                </div>

                <h2>3. Creating a post</h2>
                <div style="background: #fff; border: 1px solid #ccd0d4; padding: 20px; max-width: 600px; margin-top: 10px; margin-bottom: 30px;">
                    <ol style="margin-top: 0; margin-bottom: 0; padding-left: 20px;">
                        <li style="margin-bottom: 10px;">When publishing a post, the Sellout Crowds box will appear on the right side of the screen.</li>
                        <li>Select the Crowd or Space that you want to post to and publish the WordPress article.</li>
                    </ol>
                    <p style="margin-top: 15px; margin-bottom: 0; font-size: 13px; font-style: italic; color: #666;">
                        *Note: If the Sellout Crowds box is not appearing on your Edit Post screen, you have not properly completed the steps above. Please review those steps and try again.
                    </p>
                </div>
            </div>
        </div>
        <?php
    }

    public function register_settings() {
        register_setting( 'soc_dashboard_settings_group', 'soc_access_token' );
    }

    public function add_soc_user_profile_url_field($user) {
        ?>
        <h3 id="soc_user_profile_url">Sellout Crowds Profile Settings</h3>
        <table class="form-table">
            <tr>
                <th><label for="soc_user_profile_url_field">Author Profile URL</label></th>
                <td>
                    <input type="url" name="soc_user_profile_url" id="soc_user_profile_url_field" value="<?php echo esc_attr(get_user_meta($user->ID, 'soc_user_profile_url', true)); ?>" class="regular-text" /><br />
                    <span class="description">Enter your Sellout Crowds Profile URL to be credited as the author.</span>
                </td>
            </tr>
        </table>
        <?php
    }

    public function save_soc_user_profile_url_field($user_id) {
        if (!current_user_can('edit_user', $user_id)) {
            return false;
        }

        if (isset($_POST['soc_user_profile_url'])) {
            $raw_url = sanitize_text_field($_POST['soc_user_profile_url']);
            $clean_url = str_replace(array('https://studio.selloutcrowds.com', 'https://www.selloutcrowds.com'), 'https://selloutcrowds.com', $raw_url);
            update_user_meta($user_id, 'soc_user_profile_url', $clean_url);
        }
    }
}