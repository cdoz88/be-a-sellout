<?php
// Ensure function doesn't fatal crash if called alongside caching plugins
if (!function_exists('get_soc_api_allow_to_fields')) {

    function get_soc_api_allow_to_fields() {
        $cached = get_transient('soc_communities_cache');
        if (false !== $cached && !isset($cached['is_error']) && !isset($cached['error'])) {
            return $cached;
        }
        
        // UPDATED: Now pings office.selloutcrowds.com
        $url = "https://office.selloutcrowds.com/api/wp/get-fields";
        
        $post_fields = array(
            'access_token' => (string) get_option('soc_access_token'),
            'user'         => (string) get_option('soc_profile_url'), 
            'domain'       => (string) home_url()
        );
        $response = wp_remote_post( $url, array(
            'body'    => $post_fields, 
            'timeout' => 20, 
            'headers' => array('User-Agent' => 'UNA')
        ) );
        if ( is_wp_error( $response ) ) {
            return array('is_error' => true, 'message' => 'WP Request Timeout: ' . $response->get_error_message());
        }
        $body = wp_remote_retrieve_body( $response );
        $decoded = json_decode( $body, true );
        
        if (is_array($decoded)) {
            if (!isset($decoded['error'])) {
                // Only cache successful lookups (for 5 minutes)
                set_transient( 'soc_communities_cache', $decoded, 5 * MINUTE_IN_SECONDS );
            }
            return $decoded;
        }
        
        return array('is_error' => true, 'message' => 'Invalid JSON from Hub. Raw: ' . substr($body, 0, 100));
    }
}

if (!function_exists('get_soc_owned_profile_ids')) {

    /**
     * Queries the bridge connector to retrieve profile IDs of spaces and groups owned by the Master connected user.
     *
     * @return array Array of owned integer profile IDs or an error array.
     */
    function get_soc_owned_profile_ids() {
        $cached = get_transient('soc_owned_communities_cache');
        if (false !== $cached && is_array($cached) && !isset($cached['is_error'])) {
            return $cached;
        }

        $user_url = (string) get_option('soc_profile_url');
        if (empty($user_url)) {
            return array('is_error' => true, 'message' => 'No profile URL set in settings.');
        }

        $url = 'https://selloutcrowds.com/bridge-connector.php';
        $secret = 'K2PKWb8JWe4g99DvtKze!pZu+RC9bYqRyFRa.3a,pvM.VwrC';

        // FIX: Removed the WP user's email payload. We ONLY want to query the Master Brand URL 
        // to ensure the dropdown always shows the Brand's owned communities, not the individual writer's.
        $body = array(
            'action' => 'get_owned_profile_ids',
            'user'   => $user_url,
            'secret' => $secret // Passing securely in body to bypass server header stripping
        );

        $args = array(
            'body'        => wp_json_encode($body),
            'headers'     => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $secret, // Retained for compatibility where supported
            ),
            'timeout'     => 15,
            'data_format' => 'body',
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            error_log('SOC Plugin Error fetching owned profile IDs: ' . $response->get_error_message());
            return array('is_error' => true, 'message' => 'WP HTTP Error: ' . $response->get_error_message());
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);

        if ($response_code !== 200) {
            $error_msg = isset($decoded['error']) ? $decoded['error'] : 'Unknown error from bridge-connector. Code: ' . $response_code;
            return array('is_error' => true, 'message' => 'Bridge Error: ' . $error_msg);
        }

        // If the bridge successfully found the user and their communities
        if (isset($decoded['success']) && $decoded['success'] === true) {
            $owned_spaces = isset($decoded['owned_spaces']) && is_array($decoded['owned_spaces']) ? $decoded['owned_spaces'] : array();
            $owned_groups = isset($decoded['owned_groups']) && is_array($decoded['owned_groups']) ? $decoded['owned_groups'] : array();
            $owned_ids = array_map('intval', array_merge($owned_spaces, $owned_groups));

            set_transient('soc_owned_communities_cache', $owned_ids, 5 * MINUTE_IN_SECONDS);
            return $owned_ids;
        }

        // Handle errors generated explicitly by bridge-connector.php (e.g. "User account not found")
        $error_msg = isset($decoded['error']) ? $decoded['error'] : 'Unknown error from bridge-connector. Raw: ' . substr($response_body, 0, 100);
        return array('is_error' => true, 'message' => 'Bridge Error: ' . $error_msg);
    }
}