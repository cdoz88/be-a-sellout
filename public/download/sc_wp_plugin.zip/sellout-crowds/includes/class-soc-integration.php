<?php
class SOC_Integration {
    public function __construct() {
        add_action('save_post', array($this, 'soc_on_save_post'), 10, 3);
        add_action('wp_trash_post', array($this, 'soc_on_trash_post'));
    }

    public function soc_on_save_post($post_id, $post, $update) {
        if (wp_is_post_revision($post_id)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!current_user_can('edit_post', $post_id)) return;
        
        // Nonce check
        $nonce = $_POST['soc_allow_view_meta_box_nonce_field'] ?? '';
        if (!wp_verify_nonce($nonce, 'soc_allow_view_meta_box_nonce')) return;
        
        // Save meta field
        if (!isset($_POST['soc_allow_view'])) {
            delete_post_meta($post_id, '_soc_allow_view');
        } else {
            update_post_meta($post_id, '_soc_allow_view', sanitize_text_field($_POST['soc_allow_view']));
        }

        $soc_api = new SOC_API();
        $post_id_on_api = get_post_meta($post_id, '_soc_post_id', true);

        if ($post->post_status === 'publish') {
            $post_image_link = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
            $author_id = $post->post_author;
            $author_una_url = get_user_meta($author_id, 'soc_user_profile_url', true);

            if (empty($author_una_url) || !filter_var($author_una_url, FILTER_VALIDATE_URL)) {
                error_log("SOC Plugin: Post $post_id not sent. Author $author_id has no valid UNA profile URL set.");
                return; 
            }

            if ($post_id_on_api) {
                $soc_api->editPost($post_id, $post->post_title, $post->post_content, $post_image_link, get_permalink($post), $author_una_url);
            } else {
                $new_post_id_api = $soc_api->createPost($post_id, $post->post_title, $post->post_content, $post_image_link, get_permalink($post), $author_una_url);
                if ($new_post_id_api) {
                    update_post_meta($post_id, '_soc_post_id', $new_post_id_api);
                }
            }
        } elseif ($post->post_status === 'draft' && !empty($post_id_on_api)) {
            delete_post_meta($post->ID, '_soc_allow_view');
            $soc_api->deletePost($post->ID);
            delete_post_meta($post->ID, '_soc_post_id');
        }
    }

    public function soc_on_trash_post($post_id) {
        $post_ids = [];
        if (isset($_GET['post']) && is_array($_GET['post'])) {
            $post_ids = array_map('intval', $_GET['post']);
        } else {
            $post_ids[] = (int) $post_id;
        }
        $soc_api = new SOC_API();
        foreach ($post_ids as $id) {
            $post = get_post($id);
            if (!$post || $post->post_type !== 'post') continue;
            $api_post_id = get_post_meta($id, '_soc_post_id', true);
            if (empty($api_post_id)) continue;
            delete_post_meta($id, '_soc_allow_view');
            $soc_api->deletePost($id);
            delete_post_meta($id, '_soc_post_id');
        }
    }
}