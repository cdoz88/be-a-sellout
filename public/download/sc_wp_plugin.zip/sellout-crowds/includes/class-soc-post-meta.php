<?php
class SOC_Post_Meta {

    public function __construct() {
        add_action('add_meta_boxes', array($this, 'soc_allow_view_meta_box'));
        add_action('wp_ajax_soc_get_communities', array($this, 'ajax_get_communities'));
    }

    public function soc_allow_view_meta_box() {
        add_meta_box(
            'soc_meta_box_id',
            'Sellout Crowds',
            array($this, 'soc_custom_meta_box_callback'),
            'post',
            'side',
            'high'
        );
    }

    public function soc_custom_meta_box_callback($post) {
        echo '<div style="display: flex; align-items: center; margin-bottom: 15px; border-bottom: 1px solid #ddd; padding-bottom: 10px;">';
        echo '<img style="width: 24px; margin-right: 8px;" src="'.plugin_dir_url(__FILE__).'images/icon.png">';
        echo '<strong>Post to Community</strong>';
        echo '</div>';

        if (!get_option('soc_access_token')) {
            echo '<p style="color:#d63638;">Please connect your Sellout Crowds account in settings.</p>';
            return;
        }

        wp_nonce_field('soc_allow_view_meta_box_nonce', 'soc_allow_view_meta_box_nonce_field');

        echo '<div id="soc-communities-container">';
        echo '<p style="color:#666;">Loading communities...</p>';
        echo '</div>';

        echo '<script>
        jQuery(document).ready(function($) {
            var socAjaxUrl = "' . admin_url('admin-ajax.php') . '";
            $.post(socAjaxUrl, { action: "soc_get_communities", post_id: ' . $post->ID . ' }, function(response) {
                $("#soc-communities-container").html(response);
            }).fail(function(xhr, status, error) {
                $("#soc-communities-container").html("<p style=\'color:#d63638;\'>AJAX Failed. " + error + "</p>");
            });
        });
        </script>';
    }

    public function ajax_get_communities() {
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $selected_option = $post_id ? get_post_meta($post_id, '_soc_allow_view', true) : '';
        $selected_option_first = empty($selected_option) ? 'checked' : '';

        $api_data = get_soc_api_allow_to_fields();
        $owned_ids = get_soc_owned_profile_ids();

        echo '<label><input type="radio" '.$selected_option_first.' name="soc_allow_view" value="">No</label><br>';

        // Catch Hub API Errors
        if (isset($api_data['error']) || isset($api_data['is_error'])) {
            $err_msg = isset($api_data['error']) ? $api_data['error'] : $api_data['message'];
            echo '<p style="color:#d63638; font-weight:bold; margin-top:10px;">Error Loading Data:</p>';
            echo '<p style="font-size:11px; color:#666;">' . esc_html($err_msg) . '</p>';
            wp_die();
        }

        // Catch Bridge Connector Ownership Sync Errors
        if (isset($owned_ids['is_error'])) {
            echo '<p style="color:#d63638; font-weight:bold; margin-top:10px;">Ownership Sync Error:</p>';
            echo '<p style="font-size:11px; color:#666;">' . esc_html($owned_ids['message']) . '</p>';
            wp_die();
        }

        $options = (isset($api_data['allow_view_to']['values']) && is_array($api_data['allow_view_to']['values'])) ? $api_data['allow_view_to']['values'] : [];

        if (empty($options)) {
            echo '<p style="color:#d63638; font-weight:bold; margin-top:10px;">No communities found.</p>';
        } else {
            // Define default UNA privacy levels to hide
            $hidden_options = array('Public', 'Friends', 'Only me');
            $rendered_count = 0;

            foreach ($options as $label) {
                if (isset($label['key']) && isset($label['value'])) {
                    // Skip rendering default UNA privacy levels
                    if (in_array(trim($label['value']), $hidden_options)) {
                        continue;
                    }

                    // Extract the community Profile ID (UNA context keys are negative integers, e.g. -105)
                    $community_profile_id = abs(intval($label['key']));

                    // Strictly filter out any community that is not owned by the user
                    if (empty($owned_ids) || !in_array($community_profile_id, $owned_ids, true)) {
                        continue;
                    }

                    echo '<label><input type="radio" name="soc_allow_view" value="' . esc_attr($label['key']) . '" ' . checked($selected_option, $label['key'], false) . '> ' . esc_html($label['value']) . '</label><br>';
                    $rendered_count++;
                }
            }

            if ($rendered_count === 0 && !empty($options)) {
                echo '<p style="color:#666; font-size:12px; margin-top:8px;">No owned communities found for this account.</p>';
            }
        }

        wp_die();
    }
}