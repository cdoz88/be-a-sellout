<?php

class SOC_API {

    private $accessToken;
    private $domain;
    private $apiUrlBase;

    public function __construct() {
        $this->accessToken = get_option('soc_access_token');
        $this->domain = home_url();
        
        // UPDATED: Now pings office.selloutcrowds.com
        $this->apiUrlBase = "https://office.selloutcrowds.com/api/wp/";
    }

    /**
     * Processes the post content to extract fallback images and replace raw embed URLs with rich HTML.
     * Handles Getty Images, YouTube, and Twitter/X links natively.
     * 
     * @param string &$text The post content (passed by reference so we can modify it).
     * @param string $current_image The existing featured image link (if any).
     * @return string The resolved image link to send to Sellout Crowds.
     */
    private function process_content_and_image(&$text, $current_image) {
        $image_link = $current_image;

        // 1. Process Getty Images
        if (preg_match_all('/https?:\/\/gty\.im\/[0-9]+/i', $text, $matches)) {
            $getty_urls = array_unique($matches[0]);

            foreach ($getty_urls as $getty_url) {
                $oembed_url = 'https://embed.gettyimages.com/oembed?url=' . urlencode($getty_url);
                $response = wp_remote_get($oembed_url, array('timeout' => 10));
                
                $thumbnail_url = '';
                if (!is_wp_error($response)) {
                    $data = json_decode(wp_remote_retrieve_body($response), true);
                    if (isset($data['thumbnail_url']) && !empty($data['thumbnail_url'])) {
                        // Use the exact URL returned by Getty without modifying parameters
                        $thumbnail_url = $data['thumbnail_url'];
                        
                        if (empty($image_link)) {
                            $image_link = $thumbnail_url;
                        }
                    }
                }

                if (!empty($thumbnail_url)) {
                    // Set width strictly to 300px (max-width: 100% ensures it scales down on smaller screens if needed)
                    $html_image = '<br><img src="' . esc_url($thumbnail_url) . '" style="width: 300px; max-width: 100%; height: auto; border-radius: 8px; margin: 15px auto; display: block;" /><br> ';
                    $text = str_replace($getty_url, $html_image, $text);
                } else {
                    $text = str_replace($getty_url, ' ', $text);
                }
            }
        }

        // 2. Process YouTube Links into Responsive Iframes
        if (preg_match_all('/https?:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i', $text, $yt_matches)) {
            $yt_urls = array_unique($yt_matches[0]);
            
            foreach ($yt_urls as $index => $yt_url) {
                $video_id = $yt_matches[1][$index];
                // Build a responsive iframe that maxes out at 600px wide for desktop reading
                $iframe = '<br><iframe width="100%" height="315" src="https://www.youtube.com/embed/' . esc_attr($video_id) . '" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="width: 100%; max-width: 600px; aspect-ratio: 16/9; border-radius: 8px; margin: 15px auto; display: block;"></iframe><br> ';
                $text = str_replace($yt_url, $iframe, $text);
            }
        }

        // 3. Process Twitter / X Links into Native Embeds
        if (preg_match_all('/https?:\/\/(?:www\.)?(?:twitter\.com|x\.com)\/[a-zA-Z0-9_]+\/status\/[0-9]+/i', $text, $tw_matches)) {
            $tw_urls = array_unique($tw_matches[0]);
            
            foreach ($tw_urls as $tw_url) {
                // Utilize WordPress's native oEmbed fetcher to grab official Twitter HTML
                $embed_html = wp_oembed_get($tw_url);
                if ($embed_html) {
                    $html = '<br><div style="display: flex; justify-content: center; margin: 15px 0; max-width: 100%; overflow: hidden;">' . $embed_html . '</div><br> ';
                    $text = str_replace($tw_url, $html, $text);
                } else {
                    // Fallback link if Twitter API is unreachable
                    $fallback = '<br><a href="'.esc_url($tw_url).'" target="_blank" style="color: #1da1f2; text-decoration: underline;">View Post on X (Twitter)</a><br> ';
                    $text = str_replace($tw_url, $fallback, $text);
                }
            }
        }
        
        // 4. Fallback: Check for a standard HTML <img> tag in the post content
        if (empty($image_link) && preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $text, $matches)) {
            $image_link = $matches[1];
        }

        return $image_link;
    }

    public function createPost($postId, $title, $text, $image_link, $post_link, $author_una_url) {
        $allowViewTo = get_post_meta($postId, '_soc_allow_view', true);

        if (empty($allowViewTo)) {
            return false;
        }

        // Clean the text of raw embed links and extract a fallback image if necessary
        $image_link = $this->process_content_and_image($text, $image_link);

        $postData = [
            'title' => $title,
            'text' => $text,
            'allow_view_to' => $allowViewTo,
            'post_image'=> $image_link,
            'post_link'=> $post_link,
            'published' => "",
        ];

        $response = $this->sendRequest('create-post', $postData, $author_una_url);
        $response = json_decode($response, true);
        
        return isset($response['post_id']) ? $response['post_id'] : false; 
    }

    public function editPost($postId, $title, $text, $image_link, $post_link, $author_una_url) {
        $allowViewTo = get_post_meta($postId, '_soc_allow_view', true);
        $post_id_on_api = get_post_meta($postId, '_soc_post_id', true);
        
        if (empty($allowViewTo)) {
            $this->deletePost($postId);
            delete_post_meta($postId, '_soc_post_id');
            return true;
        }
        
        // Clean the text of raw embed links and extract a fallback image if necessary
        $image_link = $this->process_content_and_image($text, $image_link);

        $postData = [
            'post_id' => $post_id_on_api,
            'title' => $title,
            'text' => $text,
            'allow_view_to' => $allowViewTo,
            'post_image'=> $image_link,
            'post_link'=> $post_link,
            'published' => "",
        ];

        return $this->sendRequest('edit-post', $postData, $author_una_url);
    }

    public function deletePost($postId) {
        $post_id_on_api = get_post_meta($postId, '_soc_post_id', true);

        $postData = [
            'post_id' => $post_id_on_api
        ];
        
        $current_user_url = get_user_meta(get_current_user_id(),'soc_user_profile_url',true);

        return $this->sendRequest('delete-post', $postData, $current_user_url);
    }

    private function sendRequest($endpoint, $postData, $author_url) {
        if (empty($this->accessToken) || empty($author_url) || !filter_var($author_url, FILTER_VALIDATE_URL) || empty($this->domain) || !is_array($postData)) {
            if (empty($author_url) || !filter_var($author_url, FILTER_VALIDATE_URL)) { 
                error_log("SOC Plugin: API request failed. Invalid or empty author URL: " . $author_url);
            }
            return false;
        }

        $postFields = array(
            'access_token' => $this->accessToken,
            'user'         => $author_url, 
            'domain'       => $this->domain,
            'data'         => $postData,
        );

        $response = wp_remote_post( $this->apiUrlBase . $endpoint, array(
            'body'    => $postFields,
            'timeout' => 15,
            'headers' => array(
                'User-Agent' => 'UNA'
            )
        ) );

        if ( is_wp_error( $response ) ) {
            return "Error: " . $response->get_error_message();
        }

        return wp_remote_retrieve_body( $response );
    }
}