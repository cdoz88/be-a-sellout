<?php
/**
 * Registers custom REST API endpoints for the plugin.
 */
class SOC_Endpoints {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        register_rest_route( 'soc/v1', '/stats', array(
            'methods'  => 'GET',
            'callback' => array( $this, 'get_connection_stats' ),
            'permission_callback' => array( $this, 'check_admin_permissions' ),
        ) );

        register_rest_route( 'soc/v1', '/validate-connection', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'validate_connection_callback' ),
            'permission_callback' => array( $this, 'check_server_api_key' ),
        ) );

        register_rest_route( 'soc/v1', '/activate-connection', array(
            'methods'  => 'POST',
            'callback' => array( $this, 'activate_connection_callback' ),
            'permission_callback' => array( $this, 'check_server_api_key' ),
        ) );
    }

    public function activate_connection_callback( $request ) {
        $code = $request->get_param('code');
        if (empty($code)) {
            return new WP_REST_Response( array('status' => 'error', 'message' => 'Connection code not provided.'), 400 );
        }

        $user_query = new WP_User_Query(array(
            'meta_query' => array(
                'relation' => 'AND',
                array('key' => '_soc_connection_code', 'value' => sanitize_text_field($code)),
                array('key' => '_soc_connection_status', 'value' => 'pending')
            ),
            'number' => 1,
            'fields' => 'ID',
        ));
        $users = $user_query->get_results();

        if (empty($users)) {
            return new WP_REST_Response( array('status' => 'error', 'message' => 'No pending connection found for this code.'), 404 );
        }

        $user_id = $users[0];
        update_user_meta($user_id, '_soc_connection_status', 'active');
        delete_user_meta($user_id, '_soc_connection_code');

        return new WP_REST_Response( array('status' => 'success', 'message' => 'Connection activated successfully.'), 200 );
    }

    public function validate_connection_callback( $request ) {
        $code = $request->get_param('code');
        if (empty($code)) {
            return new WP_REST_Response( array('status' => 'error', 'message' => 'Connection code not provided.'), 400 );
        }

        $user_query = new WP_User_Query(array('meta_key' => '_soc_connection_code', 'meta_value' => sanitize_text_field($code), 'number' => 1, 'fields' => 'ID'));
        $users = $user_query->get_results();

        if (empty($users)) {
            return new WP_REST_Response( array('status' => 'error', 'message' => 'Invalid connection code.'), 404 );
        }
        
        $user_id = $users[0];
        $status = get_user_meta($user_id, '_soc_connection_status', true);

        if ($status !== 'pending') {
             return new WP_REST_Response( array('status' => 'error', 'message' => 'Connection code has already been used or is inactive.'), 410 );
        }

        return new WP_REST_Response( array('status' => 'success', 'message' => 'Code is valid.'), 200 );
    }

    public function check_server_api_key($request) {
        $auth_header = $request->get_header('Authorization');
        // FIX: Update to soc_access_token so it doesn't throw a PHP Warning when attempting to hash empty false values
        $saved_api_key = get_option('soc_access_token'); 
        if (empty($auth_header) || empty($saved_api_key)) return false;
        if (sscanf($auth_header, 'Bearer %s', $token) !== 1) return false;
        return hash_equals((string)$saved_api_key, (string)$token);
    }

    public function check_admin_permissions() {
        return current_user_can( 'manage_options' );
    }

    public function get_connection_stats() {
        $active_query = new WP_User_Query(array(
            'meta_key'   => '_soc_connection_status',
            'meta_value' => 'active',
            'count_total'=> true,
            'fields'     => 'ID',
        ));
        $active_user_count = $active_query->get_total();
        
        $pending_query = new WP_User_Query(array(
            'meta_key'   => '_soc_connection_status',
            'meta_value' => 'pending',
            'count_total'=> true,
            'fields'     => 'ID',
        ));
        $pending_user_count = $pending_query->get_total();

        $response_data = array(
            'active_connections' => $active_user_count,
            'pending_invites'    => $pending_user_count,
        );

        return new WP_REST_Response( $response_data, 200 );
    }
}